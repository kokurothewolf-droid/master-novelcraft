# Novel lab: one original example, multiple skills

Everything in this example is original fiction and teaching material created for this package. It is **not** an Alan Moore quotation, scene, or reproduction of his writing style. The workflow is **[A]**; individual principles are linked by P-number.

## The author brief

> I am writing a literary mystery with a little dry humor. In a river city, an archivist discovers that the public flood records have been quietly revised. Draft a close-third-person, past-tense exchange between the archivist and the maintenance supervisor. Both should have comprehensible motives. The city should feel inhabited, not explained.

**Provisional canon for this demonstration:** The city of Bellwater has warning bells, public flood ledgers and a low-lying district called Reedward. The institutions are imaginary. No real-world engineering or legal procedure is asserted.

## Bad-but-plausible draft (deliberately weak)

> Bellwater was a city with terrible floods and an elaborate government bureaucracy. Anja was the town archivist who cared deeply about the truth. Tomas was a maintenance supervisor who had changed the flood records to hide evidence of dangerous water levels. He believed the public would panic. Anja confronted him and demanded that he tell everyone. He refused because he was afraid of losing his job. They argued for a long time, after which Anja resolved to expose the deception.

**Diagnosis:** It states character labels instead of showing the collision (P02-P04); it explains the city instead of making its systems consequential (P05-P09); the event is summarized rather than experienced (P15); the antagonist has only a thin motive (P03). Those are craft judgments [A], not facts about reader neurons.

## A more purposeful version

> The warning bell rang while Anja was still holding the ledger open, and for a moment she thought the mark on the page had moved.
>
> She turned the book toward Tomas. “Look at Reedward. Last autumn.”
>
> He didn't look. He was watching a drop of water travel down the window's wired glass. The archive had been built above the old canal, which meant it always smelled faintly of wet stone, even in a drought.
>
> “I know what the number says,” he told her.
>
> “Then you know it used to say something else.”
>
> Outside, a woman in a yellow apron leaned across the street to fasten a new sign over her bakery door: *DRY FEET SPECIAL. HALF PRICE ON RAIN DAYS.* The sign had appeared every spring for as long as Anja could remember. This year, the bakery's front step sat an inch below the fresh mud line.
>
> Tomas finally reached for the book. His hands were split around the knuckles, the cuts packed dark with canal silt. Instead of touching the disputed figure, he pressed down the curling corner of the page.
>
> “The council sees the old number,” he said, “and sends thirty families out of Reedward before the gates are repaired. Where do you think they go?”
>
> Anja had wanted him to admit he had lied. It was irritating to discover he had prepared something more complicated.
>
> “You don't get to erase the water because you dislike the paperwork.”
>
> “And you don't get to call an evacuation a solution because you don't have to find the beds.”
>
> The bell sounded again, once. Not the long pattern for a rising canal. Just the hourly signal, late as usual.
>
> Anja slid a blank correction slip from the drawer. Tomas watched her write the date, then the old reading. She left the signature line empty.
>
> “I won't publish it without giving you a chance to come with me,” she said.
>
> “That's a terrible bargain.”
>
> “It's the only one in the book.”

## What changed and why

| Choice | Source-guided aim | What to avoid |
|---|---|---|
| Both characters argue from protective values | P03-P04: intelligible motives and personal agendas | Pretending the deception has no consequences or is morally neutral |
| Archive smell, baker's sign, muddy doorstep, and municipal form | P05-P07: a place with pressure and social texture | Unconnected decorative detail |
| Source of records emerges through a disputed number | P08-P09: world explanation through action | Artificial dialogue about facts both know |
| Anja's private irritation is close-third perception | P12-P13: focal character filters the encounter | Tomas's inaccessible private thoughts |
| Bell pattern and empty signature line carry information and outcome | P15, P21: sensory sequence, transitions, consequences | A gratuitous twist or endless explanation |
| One small joke about bureaucracy | P11: mixed comic and serious register | Turning a serious ethical disagreement into farce |

The passage is not perfect or mandatory. An author might prefer more procedural exactness, greater ambiguity about Tomas, or less explicit argument. Such changes would be choices, not violations of a Moore rule.

## Coaching response to the same brief

**Today's technique:** Give every important person their own internal story (P04; S04:L8 [T]).

**Explanation:** A scene becomes more specific when two people each believe they are protecting something worth protecting. Making Tomas coherent does not excuse falsifying the records.

**Exercise:** Continue the encounter for 200 words from Anja's close-third viewpoint. Include one detail from the room that changes a practical choice, and let Tomas make a decision that is understandable without giving access to his thoughts.

**What I'll inspect:** Viewpoint discipline (P12), concrete agency (P04), place exerting pressure (P05), and a meaningful new consequence [A].

## Optional mode experiment

Take the exchange at the ledger and change only **what the bell means**:

- **Comic:** The bell keeper repeatedly signals the wrong hour; a familiar civic embarrassment delays Anja at precisely the wrong moment.
- **Horrific:** The bell sounds a flood pattern that the city abolished decades ago, but Tomas insists no one is ringing it.
- **Domestic realist:** The bell is merely routine, while the bakery sign evokes a personal history between the characters.

These are alternative reader effects (P10-P11), not proof that one mode is superior.

## One-chapter test [A]

If an author proposes an additional chapter showing Anja walking from the archive to the council hall, the agent should ask what uniquely changes on that journey. If it yields a new social consequence or major decision, it may earn full chapter length. If it merely fills elapsed time, a transition could be more effective (P21), and keeping the chapter should remain the author's call.
