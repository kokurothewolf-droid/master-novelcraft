# Novel-writing workflows

All step sequences, worksheets, diagnostic orderings, and templates on this page are **[A] Adaptations**, not structures Alan Moore is documented as prescribing. Their craft goals draw on the indicated P-number principles in `principle-atlas.md`.

## Routing and scope

- For a short request, run the shortest workflow that can satisfy it. Do not force the author through intake, story bible, theme statement, and critique unless requested.
- For a long project, establish a compact `Narrative contract`: genre(s), intended feeling, audience, tense/POV, experimental range, immutable canon, prohibited changes, current timeline, and author priority. See `templates.md`.
- If the user wants both text and teaching, produce the requested text first; follow it with an explanation of only the most relevant choices.
- If facts conflict, prefer explicit author corrections and established project documentation to any invented detail. Report unresolved contradictions, do not silently repair canon.

## Workflow A. Novel concept, idea, and plot

**Use when:** brainstorming, premise development, plotting, restructuring. **Source anchors:** P01, P03-P04, P05, P10, P19.

1. Write the **essential idea** as a question, tension, or observation. Do not confuse a series of events with an idea. [P01]
2. Identify a protagonist with a credible aim, a competing person/system with its own rationale, and a place that changes the available choices. [P03-P05]
3. Choose genre promises and deliberate departures. Specify emotional/narrative mode separately. [P10-P11]
4. Derive a causal spine from choices and consequences, not unrelated episodes. This is [A], not a Moore beat sheet.
5. Offer 2-3 alternatives that shift **form or assumptions**, not just names or scenery.
6. For long-form projects, reserve unresolved tensions and a meaningful endpoint. Set aside intriguing side stories unless they strengthen the work. [P19]

**Return:** an idea statement, a 2-5 sentence premise, principal agenda collisions, stakes, major movement, and optional exploratory variants. Don't assume a heroic journey, three acts, or one correct structure.

## Workflow B. Characters and dialogue

**Use when:** creating character profiles, testing scenes, revising dialogue. **Source anchors:** P02-P04, P12-P13.

1. Write each person's **self-story**: what they believe the world owes them, what they protect, and how they justify themselves. [P04]
2. Explore bodily particulars grounded in circumstances and research: stature affects reach, injury affects pace, training affects attention, culture affects interaction, sensory differences alter what is noticed. [P02]
3. Give the antagonist a credible account of events in which they are not a prop for the hero. Do not grant automatic moral equivalence. [P03]
4. For a live scene, put characters into collision with different objectives. Test dialogue: what is each utterance trying to accomplish? [A]
5. If the planned line or action violates established personality, either establish a credible new pressure or alter the plan. [P04]
6. In close POV, restrict perception and interior access to the viewpoint character. Dialogue can reveal the other character's motive indirectly. [P12-P13]

**Return:** only the level of dossier the author needs, or the scene itself. Avoid personality-test jargon unless requested.

## Workflow C. Place, worldbuilding, and historical grounding

**Use when:** building cities, revising setting, writing historically situated fiction. **Source anchors:** P05-P09.

1. Ask how geography, economy, institutions, memory, and status shape people from this place. [P05]
2. Separate **confirmed real facts**, **author-set canon**, **open research questions**, and **invented texture**. [P06]
3. For invented worlds, define a few relevant stable rules, their limitations, and what visible consequences citizens would adapt to. [P07]
4. Select 2-4 unobtrusive everyday artifacts: an announcement, advertisement, snack, idiom, tax, joke, local song, newspaper headline, architectural repair, transit rule. [P07]
5. Introduce setting via action or stakes. Some initial unfamiliarity is welcome if the immediate human problem remains intelligible. [P08-P09]
6. Check route and era details where they matter. If tools are absent, mark research gaps openly. [P06]

**Return:** a concise place dossier or a passage that demonstrates the place affecting choices. Resist tourist-brochure exposition.

## Workflow D. Narrative voice, genre and mode

**Use when:** choosing narrator, diagnosing tonal mismatch, rewriting perspective. **Source anchors:** P10-P13.

1. Name the intended genre experience and whether conventions are honored, subverted, or mixed. [P10]
2. Name the mode of this specific passage: comic, ominous, tender, tragic, uncanny, etc. The novel may change modes across scenes. [P11]
3. Select grammatical person, tense, and distance. Define who can know what. [P12]
4. Identify the focal character's attention pattern and biases. A close narrator notices *some* details before others. [P13]
5. Compare two brief variants only when the author is deciding between voices. Contrast reader effects, not generic quality rankings. [A]

**Return:** a narrative contract and short demonstration, or a corrected passage. Don't presume that third-person equals omniscient or that tense alone guarantees immediacy.

## Workflow E. Scene and chapter drafting

**Use when:** drafting prose, repairing inert scenes, deciding whether a new chapter belongs. **Source anchors:** P01, P02-P04, P08-P09, P11-P15, P21.

**Scene pressure map [A]:**

| Field | Question |
|---|---|
| Reader effect | What should readers fear, hope, discover, laugh at, or reconsider? |
| Focal perspective | Whose access to information shapes this experience? |
| Agenda collision | What does each participant think they are trying to accomplish? |
| Place pressure | Which concrete feature of the world creates or changes a choice? |
| Expectation | What is the reader likely predicting? Is fulfillment or reversal better? |
| Change | What is different after the scene, materially or psychologically? |
| Handoff | What new question or consequence pulls into the next scene? |

Use the map internally unless the author asks to see planning. Compose continuous prose with natural rhythm, not a beat checklist on the page. Avoid mandatory cliffhangers, arbitrary twists, artificial conflict, and constant metaphors.

**Chapter contribution check [A]:** A proposed chapter can earn its place by transforming plot, relationship, place, knowledge, or reader interpretation. Quiet chapters may still earn their place through mood, intimacy, and thematic deepening. Before inserting a chapter to fill an apparent gap, ask: *Does the gap represent missing causality or merely an invitation to expand?* If it adds no valued change, merge, defer, or cut.

**Transitions:** Carry forward a physical object, image, unresolved decision, emotional change, or chronological cue as appropriate. Hard cuts are acceptable when deliberate. [P21]

**Return:** requested passage or chapter plan, no unsolicited table if user asked for prose.

## Workflow F. Revision and prose

**Use when:** polishing, tightening, strengthening imagery, preserving voice. **Source anchors:** P09, P12-P17, P21.

1. Determine what the author wants the passage to do and which phrases they intentionally value.
2. Fix **meaning/canon** errors and broken agency first. [A]
3. Address **reader orientation**: POV, time, place, who wants what, transitions, when information enters. [P09, P12, P21]
4. Strengthen **embodiment**: purposeful physical details from this person's experience. [P02, P15]
5. Refine **sentence work**: word order, precision, rhythm, cliché, controlled juxtaposition. [P14-P15]
6. Consider **one optional experiment** in language or perception if invited. [P16-P17]
7. Compare original and revision for lost humor, warmth, strangeness, pacing, or deliberate roughness; restore valued idiosyncrasy. [A]

**Return:** prioritized critique or rewrite according to permission. For large manuscripts, diagnose representative patterns and cite locations rather than claiming to evaluate unread chapters.

## Workflow G. Creative block, risk, and completion

**Use when:** an author is stalled, over-outlining, adding scenes compulsively, or uncertain what to do next. **Source anchors:** P17-P20.

1. Diagnose the bottleneck using the four weapons metaphor: material access, intellectual discrimination, compassionate understanding, or sustained will. [P18]
2. Set a bounded artifact: one scene, a character argument, a 300-word experiment, or a chapter's unique contribution. The word count is a practical example [A], not a Moore rule.
3. Permit risk inside a controlled experiment, not necessarily in the canonical manuscript. [P17, P20]
4. Distinguish attractive new ideas from essential repairs. Keep a `Later Ideas` list instead of inserting every notion immediately. [P19; method is A]
5. Define a small completion test and move the artifact from hypothetical to reviewable. [P19]

**Return:** one next action and a draft or exercise. Never shame the author for imperfect progress.

## Hand-offs across sessions [A]

At a session boundary, optionally summarize:

- **Last completed:** what was produced and approved.
- **Canon changes:** only author-approved facts.
- **Still open:** author decisions and research gaps.
- **Next action:** finite task and success condition.

If there is no persistent file or memory mechanism, present this summary as copyable text, not a claim that it was saved.
