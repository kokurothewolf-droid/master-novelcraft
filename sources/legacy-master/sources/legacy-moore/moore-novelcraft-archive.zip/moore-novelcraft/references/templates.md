# Optional copyable templates

These are **[A] Adaptations** for an AI agent or author. They are not Moore-authored forms. Fill only useful fields; blank fields are legitimate.

## 1. Minimal writing brief

```markdown
TASK: [draft / coach / edit / plan / hybrid]
UNIT: [idea / character / scene / chapter / novel / excerpt]
GENRE AND MODE: [e.g., cozy fantasy; comic with sincere emotional stakes]
READER EFFECT: [what the audience should feel or infer]
NARRATOR: [person, tense, distance, if established]
AUTHOR VOICE: [what to preserve, what to avoid]
CANON / CONSTRAINTS: [facts that must not change]
DELIVERABLE: [format, size, degree of editorial explanation]
SOURCE OR RESEARCH GAPS: [if any]
```

## 2. Narrative contract / story bible

```markdown
# Project
Premise:
Essential idea / live question:
Genre promises and deliberate subversions:
Emotional mode range:
Audience and boundaries:
Narration: person, tense, distance, allowed shifts:
Style anchors: distinctive traits to preserve, common pitfalls to avoid:

# Immutable canon
- People: appearances, relationships, speech patterns, abilities, established facts
- World: geography, institutions, physical or magical rules, social texture
- Timeline: dates, age, event order, travel constraints

# Character agendas
| Character | Self-story | Wants | Fears | Embodied habits | Knows / misunderstands |

# Current narrative state
Last finished unit:
Consequences still active:
Unanswered questions:
Author-approved changes:
Proposed but not approved:
Research to verify:
Later ideas parking lot:
```

**Rule:** Only label as immutable when explicitly confirmed by the author or established in supplied canon. Do not automatically treat generated suggestions as canon.

## 3. Scene pressure map

```markdown
Scene identifier / location / time:
POV holder and knowledge limit:
Intended reader effect:
What POV character wants:
What every other important character wants:
Specific pressure caused by place / institutions / bodily condition:
Reader's expected outcome:
What actually happens, and why:
Choice / reversal / discovery:
Material or emotional consequence:
What carries into next scene:
Moore principles selected (up to four):
Open canon questions:
```

## 4. Chapter contribution decision

```markdown
Proposed chapter:
Why it exists (one sentence):
What becomes different by its end:
What unique reader experience it offers:
Is the chapter necessary for causality, intimacy, mystery, or place?
Would it work better as a scene, a passage, an implication, or an omitted event?
New continuity dependencies created:
Decision: KEEP / MERGE / DEFER / CUT
```

This prevents adding chapters simply because a timeline contains an unfilled interval; it does **not** forbid interludes, atmosphere, or deliberate digression.

## 5. Targeted critique

```markdown
Intended effect:
Observed strengths with examples:
Top issue #1: [where / why it matters / P-reference / fix / defect-tradeoff-preference]
Top issue #2:
Optional experiment:
What to preserve untouched:
Next action:
```

## 6. Coaching lesson

```markdown
Today's technique:
Grounding: [P## and S## / T-Q-A status]
Plain-language explanation:
Original bad-to-better illustration:
Exercise:
What success looks like:
Learner attempt:
Targeted feedback:
Next variation, if requested:
```

## 7. End-of-session handoff

```markdown
Completed and approved:
Canon updates explicitly confirmed:
Current voice and format settings:
Open questions / unverified details:
Later ideas, not yet incorporated:
Next finite artifact:
```
