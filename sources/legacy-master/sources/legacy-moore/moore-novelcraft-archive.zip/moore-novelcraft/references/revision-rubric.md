# Manuscript and scene diagnostic rubric

**[A] Adaptation:** This is a pragmatic evaluation framework derived from the source principles, **not** a scoring system proposed by Moore. It measures editorial concerns, not literary worth. Judge each dimension against the *author's intended reader experience*. Some dimensions are intentionally inapplicable to some works.

## Read before rating

Capture what the author intended to achieve, what you actually read, what genre and narrator contract govern the passage, and any known canon. Do not pretend to have assessed chapters not supplied. Separate:

- **Defect:** a contradiction, break in POV, confused causality, unintended expositional dump, or involuntary tonal mismatch.
- **Tradeoff:** a conscious choice that advances one aim while sacrificing another, such as speed versus texture.
- **Preference:** an alternative way of telling that is not inherently superior.

## Diagnostic dimensions

| Dimension | Source principles | Questions to ask | Common corrective move |
|---|---|---|---|
| Essential idea and causal drive | P01, P19 | Is there an underlying concern? Does each major event test it through choices? | Clarify the tension or make a passive event consequential. |
| Independent character agency | P02-P04 | Does each significant character act from a coherent inner account? | Restore a neglected person's agenda or embodied reaction. |
| Empathy without simplification | P03, P22 | Are flawed people legible without being excused or flattened? | Give a specific motive, consequence, or contradiction. |
| Place and period | P05-P07 | Does the environment create real pressure? Are period/place details reliable? | Research the high-impact uncertainty and replace generic scenery. |
| World texture and information | P07-P09 | Do details suggest a lived-in system? Is the reader productively curious rather than lost? | Swap one lecture for a consequence or artifact; orient stakes. |
| Genre and emotional mode | P10-P11 | Is the reader's expectation managed to produce the intended feeling? | Adjust setup, reversal, emphasis, or aftermath. |
| Narratorial contract | P12-P13 | Is tense, POV, distance and subjectivity stable unless purposefully shifted? | Repair access violations; recalibrate interior diction. |
| Language and imagined experience | P14-P17 | Are details precise and sequenced? Is surprise purposeful? | Cut worn phrasing, rearrange perception, try one bounded experiment. |
| Immersion and transitions | P08-P09, P21 | Are scene joins legible, exposition motivated, information timed? | Add an anchor or remove an unnecessary bridge. |
| Completion and proportionality | P18-P20 | Does revision target the most valuable improvement instead of endless expansion? | Set a finite revision pass and move on. |

## Optional four-level scale [A]

Only use if the author requests ratings, comparison, or systematic tracking:

- **1 = Obstructive:** materially prevents the intended effect.
- **2 = Uneven:** a recognizable positive intent with repeated interruptions.
- **3 = Functional:** effect is clear; refinements could strengthen it.
- **4 = Distinctive:** especially effective for the chosen aim, with little immediate need to change.
- **N/A = Not judged:** irrelevant to this excerpt or not enough text.

Do not compute a total score or imply numerical objectivity unless the author specifically requests it. For mixed genres or highly experimental works, some seemingly awkward choices are intentional; ask or frame as tradeoffs.

## Severity and priority

1. **Critical:** breaches author constraints, established canon, or basic comprehensibility.
2. **High:** character choices are unconvincing, central situation is inert, or narrative mode sabotages the intended effect.
3. **Medium:** exposition, pacing, or viewpoint filter sometimes interrupts immersion.
4. **Low:** local diction, repetition, clichés, small transition snags.

Priority is based on effect, not frequency alone. A single POV mistake can matter more than a dozen harmless adverbs. A repeated stylistic pattern may be deliberately part of the narrator's identity.

## Output template

**Intended effect:** [author's goal or clearly labeled assumption]

**What already works:** [1-3 concrete observations with passage evidence]

**Highest-impact opportunities:**

1. **Location:** [exact phrase, paragraph, scene, or chapter]
   **Observation:** [what is demonstrably on the page]
   **Reader effect:** [likely consequence, expressed as a possibility, not a certainty]
   **Basis:** [P-number; note adaptation if relevant]
   **Fix:** [specific revision or choice of options]
   **Type:** [defect/tradeoff/preference]

**One optional experiment:** [an appropriately bounded craft variant]

**Next revision pass:** [finite action and a way to tell when done]

For long manuscripts, organize by patterns with examples, not a running complaint log. For requested line edits, provide clean revised text plus a short change rationale.

## Do-not-do list

- Do not tell a writer to add conflict, symbolism, prose flamboyance, or a twist to every page.
- Do not use “show, don't tell” as a universal command; purposeful telling can be elegant.
- Do not demand that every secondary character receive equal space.
- Do not rate the author as a person or infer neurological effects from a sentence.
- Do not smuggle in a commercial plot template as if it came from the source corpus.
- Do not change identity, relationship dynamics, world rules, or narrative perspective without permission.
