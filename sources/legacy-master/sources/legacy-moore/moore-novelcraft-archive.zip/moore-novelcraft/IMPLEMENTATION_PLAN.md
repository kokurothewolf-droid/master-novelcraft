# Finalized implementation plan

## Project decisions (provided by the author)

| Decision | Locked choice |
|---|---|
| Portable platform | Host-independent `SKILL.md` plus relative Markdown references |
| Behavior | Both collaborator and coach; editor/hybrid extensions |
| Novel scope | Universal, adaptable to all major literary genres and mixed forms |
| Source fidelity | Faithful to source teachings, supplemented with openly labeled novel-specific adaptations |
| Source corpus | Seven user-uploaded documents; no automatic external research |

## Architecture

**1. Compact activation layer.** `SKILL.md` defines scope, mode routing, authorial control, core craft priorities, output behavior and just-in-time reference loading. It contains everything needed for short tasks, while deeper advice lives in separate files.

**2. Explicit provenance layer.** `references/source-ledger.md` names all seven inputs, differentiates transcripts, secondary quotations and commentary, records source-location pointers, and makes limitations plain. Original supplied Markdown copies reside in `sources/` for local checking.

**3. Synthesized knowledge layer.** `references/principle-atlas.md` organizes 22 principles without treating overlap as independent authority. Each entry states a supported claim, use cases, counterindications, and a test for reader effect. The adaptation register explicitly identifies methods invented for AI operations.

**4. Production layer.** `references/workflows.md` supplies task-sized methods for ideas and plots, character, place, narration, scenes and chapters, language revision, and overcoming a block. No fixed story structure is mandatory.

**5. Learning and editorial layer.** `references/coaching-and-exercises.md` provides lessons and exercises; `references/revision-rubric.md` provides observations, severity and an optional qualitative scale; `references/templates.md` makes continuity and work handoffs easier.

**6. Evidence of use and validation.** `examples/novel-lab.md` illustrates deliberate application through an original fictional scene and a teaching variant. `tests/acceptance-tests.md` defines behavioral checks; `tests/check_package.py` verifies static package integrity. `VALIDATION_REPORT.md` records what was actually tested.

## Operating assumptions

- Source documents are user-provided, not externally authenticated.
- The article is a secondary interpretation with some Moore-attributed quotes; its author's advice is not presented as Moore's.
- The original source files are bundled for private/source-traceable use and need not be automatically loaded every time.
- The author always controls genre, voice, character canon, moral choices, experiment intensity, and substantive rewrites.
- An optional project story bible is separate from this general-purpose skill; generated suggestions are not canon until approved.

## Execution order followed

1. Inventory and read all seven documents.
2. Deduplicate overlapping techniques and separate primary-attributed transcript material from secondary commentary.
3. Create principle map and record source line anchors.
4. Define runtime instructions and modes.
5. Create workflow, coaching, evaluation and continuity references.
6. Add original examples and manual acceptance tests.
7. Run static integrity check, record result, and package ZIP.

## What is deliberately excluded

A Moore-style prose simulator; undocumented Moore rules about beat sheets or scene lengths; factual claims of neuroscience proof; genre-dependent plot requirements; tool-specific file APIs, subscriptions or remote services; automatic rewriting against author wishes; and a fictional project canon hardcoded into the reusable skill.
