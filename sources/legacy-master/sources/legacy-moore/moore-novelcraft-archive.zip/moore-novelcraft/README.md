# Moore Novelcraft

A portable, source-traceable AI skill for writing, improving, and learning to write **original novels** using ideas contained in seven user-supplied Alan Moore-related sources.

**Modes:** creative collaborator, writing coach, manuscript editor, or hybrid.  
**Genres:** general, including fantasy, romance, comedy, horror, mystery, literary, and cross-genre work.  
**Fidelity:** principles are grounded in the supplied corpus; AI-specific writing procedures are labeled **[A] Adaptation**.  
**Implementation:** Markdown only for runtime instructions. No API keys, paid services, special plugins, or required scripts.

This is an independently constructed skill based on supplied materials, **not an official Alan Moore publication, endorsement, or style emulator**.

## Install

1. Extract the ZIP while preserving the `moore-novelcraft/` folder and its subdirectories.
2. In a skill-compatible agent, register or copy that folder into the environment's supported skills directory, following the host's own installation conventions. The entry point is `SKILL.md`.
3. In a generic AI chat without skill-folder support, provide `SKILL.md` as instructions and attach the relevant files from `references/` on demand. Start with `principle-atlas.md` if doing source-grounded analysis.
4. Add your manuscript, canon notes, and preferences when you want the skill to work on a specific novel. No project-specific facts are built into the skill.

**Note:** Skill discovery syntax and installation paths differ across ChatGPT, Claude, Hermes, Codex and other agents. This bundle intentionally avoids relying on a single platform's paths, APIs, or tool calls. Some environments do not automatically load relative reference files; attach them manually if needed.

## Typical prompts

- “Use Moore Novelcraft as a collaborator. Give me three distinct directions for my contemporary mystery, each with a clear essential idea and conflicting character motives.”
- “Use Moore Novelcraft as a tutor. Teach me how place changes character psychology, then assign an exercise based on my draft.”
- “Critique this chapter without rewriting it. Prioritize character integrity, point-of-view consistency, and the function of transitions.”
- “Draft this scene in a warm, comedic mode, close third past, while keeping these five canon facts unchanged. Give only two short craft notes afterward.”
- “I have a proposed new chapter. Test whether it adds a unique change or whether the gap should remain unfilled.”
- “Compare three possible points of view for this passage. Explain the tradeoffs and recommend one for my intended reader effect.”

## Directory

```text
moore-novelcraft/
├── SKILL.md                         # Main, concise runtime instructions
├── README.md                        # Installation and examples
├── IMPLEMENTATION_PLAN.md           # Design decisions and architecture
├── VALIDATION_REPORT.md             # Static checks and test limitations
├── references/
│   ├── principle-atlas.md           # 22 source-derived principles + adapter register
│   ├── source-ledger.md             # Attribution and exact source pointers
│   ├── workflows.md                 # Task-specific operational guidance
│   ├── coaching-and-exercises.md    # Practical learning curriculum
│   ├── revision-rubric.md           # Editorial diagnostics
│   └── templates.md                 # Briefs, story bible, continuity, critique
├── examples/
│   └── novel-lab.md                 # Original worked narrative example
├── tests/
│   ├── acceptance-tests.md          # Manual model behavior checks
│   └── check_package.py             # Optional Python static verifier
└── sources/
    └── S01-S07...                  # Seven original user-supplied Markdown files
```

## What it actually does

The methodology emphasizes the distinction between **idea and plot**, independent character agency, embodied characterization, empathy toward antagonists, setting as psychological and material pressure, invented-world consistency, research, genre conventions and subversions, comic/horrific expectations, narrative point of view, careful choice of language, creative experiments, and finishing work.

It deliberately **does not** require a three-act structure, inciting incident timing, novel word counts, an opening action scene, relentless metaphors, fantastical vocabulary, or imitation of Moore's phrasing. Those rules are not warranted by the supplied sources.

## Sources and limitations

- **S01/S03/S04/S05/S06/S07:** first-person, Moore-attributed transcript text supplied by the user. Not verified against source recordings.
- **S02:** the LitReactor article on Moore's *Writing for Comics*. It contains Moore-attributed quotations and the journalist's independent advice. The two are labeled separately.
- **S01 and S07** overlap on Shakespeare, Lovecraft, linguistic novelty and some experimental methods; overlap has been consolidated.
- Some cognitive-science assertions within the transcripts are unverified here. The skill uses their artistic implications without claiming scientific proof.
- Reusable writing workflows, story-bible schemas, the rubric, and the coaching sequence are explicitly **[A]**.

## Validation

The optional script can verify packaging integrity:

```bash
cd moore-novelcraft
python3 tests/check_package.py
```

Then use `tests/acceptance-tests.md` for behavioral checks in the actual AI host. Static validation does not certify a model's literary judgment or consistent adherence to instructions.

## Updating

You can add further source material by registering it in `references/source-ledger.md`, adding or refining P-number entries in `references/principle-atlas.md`, and updating the runtime routing in `SKILL.md`. Clearly label new excerpts, commentary, independent research and adaptations. Keep author preferences in a **separate project-specific file**, not in this universal skill.
