#!/usr/bin/env python3
"""Lightweight, optional integrity check for Moore Novelcraft. Standard library only.

This checks references and source location pointers. It does not evaluate an AI's behavior.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "SKILL.md", "README.md", "IMPLEMENTATION_PLAN.md",
    "references/principle-atlas.md", "references/source-ledger.md",
    "references/workflows.md", "references/coaching-and-exercises.md",
    "references/revision-rubric.md", "references/templates.md",
    "examples/novel-lab.md", "tests/acceptance-tests.md",
]
SOURCES = {
    "01": "S01-language-experiments.md",
    "02": "S02-litreactor-writing-guide.md",
    "03": "S03-place-and-time.md",
    "04": "S04-character.md",
    "05": "S05-genre-mode-voice.md",
    "06": "S06-four-weapons.md",
    "07": "S07-language-reader.md",
}
errors: list[str] = []

for rel in REQUIRED:
    path = ROOT / rel
    if not path.is_file() or not path.read_text(encoding="utf8").strip():
        errors.append(f"Missing or empty: {rel}")
for stem in SOURCES.values():
    path = ROOT / "sources" / stem
    if not path.is_file():
        errors.append(f"Missing source: {stem}")

entry = ROOT / "SKILL.md"
if entry.is_file():
    raw = entry.read_text(encoding="utf8")
    if not raw.startswith("---\n") or "\nname: moore-novelcraft\n" not in raw:
        errors.append("SKILL.md must have portable YAML frontmatter and name")
    if not re.search(r"(?m)^description:", raw):
        errors.append("SKILL.md lacks activation description")

# Check local Markdown links (not web URLs, anchors, email, or generated examples).
for md in ROOT.rglob("*.md"):
    if "sources" in md.relative_to(ROOT).parts:
        continue
    content = md.read_text(encoding="utf8")
    for target in re.findall(r"(?<!\!)\[[^\]]*\]\(([^)]+)\)", content):
        target = target.strip().split("#", 1)[0]
        if not target or target.startswith(("http://", "https://", "mailto:")):
            continue
        if not (md.parent / target).exists():
            errors.append(f"Broken link in {md.relative_to(ROOT)}: {target}")

# Each source pointer must exist and point to a real line.
ptr = re.compile(r"S(0[1-7]):L(\d+)(?:-L?(\d+))?")
for md in ROOT.rglob("*.md"):
    if "sources" in md.relative_to(ROOT).parts:
        continue
    content = md.read_text(encoding="utf8")
    for m in ptr.finditer(content):
        key, a, b = m.group(1), int(m.group(2)), int(m.group(3)) if m.group(3) else None
        file = ROOT / "sources" / SOURCES[key]
        if not file.exists():
            continue
        limit = len(file.read_text(encoding="utf8").splitlines())
        if a < 1 or a > limit or (b is not None and (b < a or b > limit)):
            errors.append(f"Invalid source line in {md.relative_to(ROOT)}: {m.group(0)}; max={limit}")

atlas = ROOT / "references" / "principle-atlas.md"
if atlas.is_file():
    found = set(re.findall(r"(?m)^### (P\d{2})\.", atlas.read_text(encoding="utf8")))
    expected = {f"P{i:02d}" for i in range(1, 23)}
    if found != expected:
        errors.append(f"Principle atlas mismatch: missing={sorted(expected-found)} excess={sorted(found-expected)}")

if errors:
    print("FAIL: package static verification")
    for error in errors:
        print(" -", error)
    sys.exit(1)
print("PASS: all required documents and seven sources are present")
print("PASS: main skill has portable frontmatter")
print("PASS: local markdown links and source line references resolve")
print("PASS: principle atlas includes P01 through P22")
print("NOTE: literary quality and model adherence require manual acceptance tests")
