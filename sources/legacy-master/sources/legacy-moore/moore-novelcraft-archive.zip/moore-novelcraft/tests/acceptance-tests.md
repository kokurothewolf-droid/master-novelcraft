# Acceptance tests and challenge prompts

These tests define **desired observable behaviors**, not a claim that every future model and host has already passed them. Use them to validate deployment on Hermes, Claude, ChatGPT, Codex, or another Markdown-instruction-capable agent. No framework-specific API is required.

## Core tests

| ID | User prompt to give the agent | Minimum acceptable behavior | Fail signal |
|---|---|---|---|
| T01 | “Draft 300 words of a tender space-opera reunion in restrained prose.” | Produces prose first; does not automatically add horror, lexical weirdness, or Moore imitation; keeps the tender tone. | Purple-prose or genre hijack. |
| T02 | “Teach me why my villain feels flat. Give me an exercise.” | Explains P03-P04, gives a short original example and a doable exercise. | Broad generic encouragement with no technique. |
| T03 | “Did Moore himself recommend Find a Grave for names?” | Distinguishes S02 journalist's recommendation [C] from Moore's quoted telephone-directory example [Q]. | Wrongly attributes Find a Grave advice to Moore. |
| T04 | “Does Moore's mirror-neuron claim prove this paragraph will make readers afraid?” | Identifies the corpus claim but says it is not scientific proof and does not guarantee reactions. | Invents evidence or claims precise brain outcomes. |
| T05 | “Please revise this scene, but keep my intentionally plain, blunt voice.” | Maintains short diction and alters only material weaknesses. | Adds persistent wordplay, high-flown metaphor, or genre shift. |
| T06 | “My fantasy city has no clocks. Show daily routines without explaining the lore in a paragraph.” | Suggests plausible indigenous temporal signals, uses artifacts/action, checks consistency. | Introduces functioning clocks or an exposition dump. |
| T07 | “Write an antagonist who orders a cruel act and thinks it is necessary.” | Renders motives without excusing the harm, centers consequences and perspective. | Flat caricature or blanket moral absolution. |
| T08 | “In close third from Mira, reveal that Joss is lying but she doesn't know it.” | Uses observable incongruities or Mira's uncertain suspicions, not unauthorized access to Joss's mind. | Narrator declares Joss's private intent as fact without focal permission. |
| T09 | “Which of these 4 chapters can I delete?” | Requests or analyzes actual chapter purposes; uses the contribution check [A] and respects quiet chapters. | Arbitrary deletion based on formula/length. |
| T10 | “Give me an Alan Moore-approved 15-beat outline.” | Explains that the corpus contains no Moore 15-beat template; can offer a clearly labeled [A] outline if useful. | Fabricates Moore-endorsed beat structure. |
| T11 | “My first chapter is a quiet, reflective opening. Must I start in medias res?” | Says no; explains P08 as optional, assesses desired effect. | Enforces an action opening as rule. |
| T12 | “Summarize what your source documents claim versus what you inferred.” | Uses P/S identifiers and [T]/[Q]/[C]/[A] distinctions. | Untraceable attribution or false external verification. |
| T13 | “Write a romantic comedy scene, then briefly explain the craft.” | Produces scene first; then 1-3 genuinely relevant notes and no lecture. | Returns only theory or an unwanted worksheet. |
| T14 | “My story has a disabled protagonist. Infer their personality from the disability.” | Refuses reductive stereotyping while offering individualized research-based characterization. | Treats a real condition as a fixed personality trait. |
| T15 | “Make this ordinary hallway genuinely uncanny using contradictory sensations.” | Applies P16 intentionally, preserves basic object/action readability. | Confuses continuity errors with purposeful ambiguity. |
| T16 | “I keep adding chapters every time I notice a gap.” | Uses A02, tests whether change is needed, suggests bounded next step. | Encourages indiscriminate expansion or dictates cuts. |

## Practical assessment

For each test, mark **Pass / Partial / Fail** with the response excerpt that supports the verdict. Check the **actual agent output**, not merely whether SKILL.md mentions the relevant principle. Run at least one challenge with a real manuscript excerpt and a known story bible before relying on the skill for a whole novel.

## Static package checks

Use `python tests/check_package.py` from the skill directory if Python is available. It checks file presence, frontmatter and local Markdown links, source line pointers, and references to cataloged principles. It does **not** test writing quality, truthful model behavior, or the validity of neuropsychological claims.
